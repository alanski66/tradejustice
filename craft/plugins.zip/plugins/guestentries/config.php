<?php

return array(
    /**
     * The name of the variable that submitted entries should be assigned to when the template is reloaded
     * in the event of a validation error.
     */
    'entryVariable' => 'entry',
);
