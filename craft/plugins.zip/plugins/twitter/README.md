# Craft Twitter

Adds tweet fields to Craft and lets you request Twitter API

-------------------------------------------

## Links

- [Twitter Plugin Overview](https://dukt.net/craft/twitter/)
- [Twitter Plugin Documentation](https://dukt.net/craft/twitter/docs)

[Dukt.net](https://dukt.net/) © 2017 - All rights reserved