<?php

return array(
	'Site Creator' => 'Site Ontwikkelaar',
	'Site Identity' => 'Site Identiteit',
	'Google Site Verification' => 'Google Site Verificatie',

	'Corporation' => 'Corporatie',
	'Organization' => 'Organisatie',
	'Person' => 'Persoon',

	'General Info' => 'Algemene Informatie',


	'Site SEO Title' => 'Site SEO titel',
	'SEO Title' => 'SEO titel',
	'Site SEO Description' => 'Site SEO omschrijving',
	'SEO Description' => 'SEO omschrijving',
	'Site SEO Image' => 'Site SEO afbeelding',
	'SEO Image' => 'SEO afbeelding',
	'Site SEO Name' => 'Site SEO naam',
	'Site SEO Keywords' => 'Site SEO keywords',
	'SEO Keywords' => 'SEO keywords',
	'Template Path' => 'Template pad',

	'Source:' => 'Bron:',
	'Custom Text' => 'Aangepaste tekst',
	'Custom Image' => 'Aangepaste afbeelding',
	'Select SEO Image' => 'Selecteer SEO afbeelding',
	'From Field' => 'Van veld',
	'Keywords From Field' => 'Keywords van veld',

	'Twitter Handle' => 'Twitter naam',
	'Facebook Handle' => 'Facebook naam',
	'Facebook Profiel ID' => 'Facebook Profiel ID',
	'LinkedIn Handle' => 'LinkedIn naam',
	'Google+ Handle' => 'Google+ naam',
	'YouTube Handle' => 'YouTube naam',
	'Instagram Handle' => 'Instagram naam',
	'Pinterest Handle' => 'Pinterest naam',

	'New Template Meta' => 'Nieuw Template Meta',
	'Untitled Meta' => 'Naamloze Meta',
);
